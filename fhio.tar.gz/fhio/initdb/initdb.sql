CREATE USER featurehub PASSWORD 'featurehub';
CREATE DATABASE featurehub;
GRANT ALL PRIVILEGES ON DATABASE featurehub TO featurehub;
